﻿using UnityEngine;
using System.Collections;

public class moveBox2 : MonoBehaviour
{

    public float speed;
    public bool moveUp;

    void Start()
    {
        gameObject.transform.position = new Vector3(-1.35f, 1, -14);
    }

    void Lerp(float a, float b, float c)
    {
        gameObject.transform.position = new Vector3(transform.position.x + a, transform.position.y + b, transform.position.z + c);
    }

    void Update()
    {
        if (Input.GetKey("w"))
        {
            moveUp = true;
        }

        if (moveUp == true && gameObject.transform.position.z < -6)
        {
            Lerp(0, 0, 1 * Time.deltaTime * speed);
        }

        if (gameObject.transform.position.z >= -6)
        {
            moveUp = false;
        }

        //if (Input.GetKey("s"))
        //{
        //    Lerp(0, 0, -1 * Time.deltaTime * speed);
        //}

        //if (Input.GetKey("a"))
        //{
        //    Lerp(-1 * Time.deltaTime * speed, 0, 0);
        //}

        //if (Input.GetKey("d"))
        //{
        //    Lerp(1 * Time.deltaTime * speed, 0, 0);
        //}

        //if (Input.GetKey("space"))
        //{
        //    Lerp(0, 1 * Time.deltaTime * speed, 0);
        //}
    }
}
