﻿using UnityEngine;
using System.Collections;

public class moveBox : MonoBehaviour {

    public float speed;

    void Start ()
    {
        gameObject.transform.position = new Vector3(0,1,-14);
	}
	
    void Lerp(float a, float b, float c)
    {
        gameObject.transform.position = new Vector3(transform.position.x + a, transform.position.y + b, transform.position.z + c);
    }

	void Update ()
    {
        if (Input.GetKey("w"))
        {
            Lerp(0, 0, 1 * Time.deltaTime * speed);
        }

        if (Input.GetKey("s"))
        {
            Lerp(0, 0, -1 * Time.deltaTime * speed);
        }

        if (Input.GetKey("a"))
        {
            Lerp(-1 * Time.deltaTime * speed, 0, 0);
        }

        if (Input.GetKey("d"))
        {
            Lerp(1 * Time.deltaTime * speed, 0, 0);
        }

        if (Input.GetKey("space"))
        {
            Lerp(0, 1 * Time.deltaTime * speed, 0);
        }
    }
}
